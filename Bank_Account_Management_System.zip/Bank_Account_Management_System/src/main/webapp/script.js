document.querySelector("form").addEventListener("submit", (e) => {
    let userId = document.querySelector("input[name='userId']").value.trim();
    let password = document.querySelector("input[name='password']").value.trim();
    if (!userId || !password) {
        e.preventDefault();
        alert("User ID and Password cannot be empty!");
    }
});
