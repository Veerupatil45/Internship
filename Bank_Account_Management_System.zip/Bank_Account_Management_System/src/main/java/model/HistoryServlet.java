package model;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/history.jsp")
public class HistoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve the logged-in user (from session, for example)
            User user = (User) request.getSession().getAttribute("user");

            // Check if the user is logged in
            if (user == null) {
                // Redirect to login page if user is not found in session
                response.sendRedirect("login.jsp");
                return;
            }

            // Assuming User has a method to get transaction history
            List<Transaction> transactions = user.getTransactionHistory(); // This needs to be implemented in User class
            request.setAttribute("transactions", transactions); // Pass the list of transactions

            // Forward to the JSP page
            request.getRequestDispatcher("history.jsp").forward(request, response);

        } catch (Exception e) {
            // Log the exception for debugging purposes
            e.printStackTrace();

            // Forward the user to an error page or show an error message
            request.setAttribute("errorMessage", "An error occurred while fetching your transaction history.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
