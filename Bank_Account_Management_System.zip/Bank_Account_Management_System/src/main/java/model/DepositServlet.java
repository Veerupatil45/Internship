package model;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class DepositServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the deposit amount from the form
        double depositAmount = Double.parseDouble(request.getParameter("depositAmount"));
        
        // Get the user object from the session
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user != null) {
            // Deposit money into the user's account
        	 BankAccount account = user.getBankAccount();
            account.deposit(depositAmount); // Make sure the deposit method is implemented in BankAccount class
            
            // Redirect back to the dashboard
            response.sendRedirect("dashboard.jsp");
        } else {
            // If user is not logged in, redirect to login page
            response.sendRedirect("login.jsp");
        }
    }
}
