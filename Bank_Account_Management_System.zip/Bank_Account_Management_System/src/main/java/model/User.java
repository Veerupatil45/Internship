package model;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String userId;
    private String password;
    private BankAccount account;
    private List<Transaction> transactionHistory;

    // Constructor, Getters, Setters, etc.

    public User(String userId, String password, BankAccount account) {
        this.userId = userId;
        this.password = password;
        this.account = account;
        this.transactionHistory = new ArrayList<>(); // Initialize transaction history
    }

    // Getter and Setter for transactionHistory
    public List<Transaction> getTransactionHistory() {
        return transactionHistory;
    }

    public void addTransaction(Transaction transaction) {
        this.transactionHistory.add(transaction);
    }

    // Other getters and setters
    public String getUserId() {
        return userId;
    }

    public BankAccount getBankAccount() {
        return account;
    }

    public void setAccount(BankAccount account) {
        this.account = account;
    }

	public Object getPassword() {
		// TODO Auto-generated method stub
		return password;
	}

    // Optional: Method to handle deposits, withdrawals, etc., which will add to transaction history
}
