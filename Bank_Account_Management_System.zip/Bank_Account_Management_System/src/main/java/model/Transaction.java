package model;

import java.util.Date;

public class Transaction {
    private String date;
    private String type; // "Deposit" or "Withdrawal"
    private double amount;
    private double balanceAfter;

    // Default Constructor
    public Transaction() {
    }

    // Parameterized Constructor
    public Transaction(String date, String type, double amount, double balanceAfter) {
        this.date = date;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
    }

    // Getters and Setters

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getBalanceAfter() {
        return balanceAfter;
    }

    public void setBalanceAfter(double balanceAfter) {
        this.balanceAfter = balanceAfter;
    }

    // Optional: Override toString for easier debugging/logging
    @Override
    public String toString() {
        return "Transaction{" +
                "date='" + date + '\'' +
                ", type='" + type + '\'' +
                ", amount=" + amount +
                ", balanceAfter=" + balanceAfter +
                '}';
    }
}
