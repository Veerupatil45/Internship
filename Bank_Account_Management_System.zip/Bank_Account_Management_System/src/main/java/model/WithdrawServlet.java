package model;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class WithdrawServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the withdrawal amount from the form
        double withdrawAmount = Double.parseDouble(request.getParameter("withdrawAmount"));
        
        // Get the user object from the session
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user != null) {
            BankAccount account = user.getBankAccount();
            double currentBalance = account.getBalance();

            // Check if the user has sufficient funds
            if (withdrawAmount > 0 && withdrawAmount <= currentBalance) {
                // Withdraw the money
                account.setBalance(currentBalance - withdrawAmount);

                // Redirect back to the dashboard
                response.sendRedirect("dashboard.jsp");
            } else {
                // If insufficient balance, display error message
                request.setAttribute("error", "Insufficient balance or invalid amount.");
                request.getRequestDispatcher("withdraw.jsp").forward(request, response);
            }
        } else {
            // If user is not logged in, redirect to login page
            response.sendRedirect("login.jsp");
        }
    }
}
