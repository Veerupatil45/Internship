package model;

import java.util.HashMap;
import java.util.Map;

public class BankAccountDao {
    private static Map<String, User> users = new HashMap<>();

    static {
        // Creating a bank account for user 'john' with an initial balance of 1000.0
        BankAccount account = new BankAccount("12345", 1000.0, 5.0);
        users.put("john", new User("john", "password123", account));
    }

    public static User getUser(String userId) {
        return users.get(userId);
    }

    // Deposit method for adding money to user's account
    public static boolean deposit(String userId, double amount) {
        User user = users.get(userId);
        if (user != null) {
        	 BankAccount account = user.getBankAccount();
            try {
                account.deposit(amount);
                return true;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                return false;
            }
        } else {
            System.out.println("User not found!");
            return false;
        }
    }
}
